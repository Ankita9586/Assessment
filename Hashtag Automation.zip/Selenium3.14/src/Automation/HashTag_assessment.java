package Automation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class HashTag_assessment {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.hashtag-ca.com/careers/apply?jobCode=QAE001");
		
	//maximize the browser
		driver.manage().window().maximize();
	//implicitly wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	driver.findElement(By.xpath("//input[@name='name']")).sendKeys("Ankita Patil");
	driver.findElement(By.xpath("//input[@name='email']")).sendKeys("ankitap9586@gmail.com");
	driver.findElement(By.xpath("//input[@name='phone']")).sendKeys(" 8007749586");
	driver.findElement(By.xpath("//input[@name='resume']")).sendKeys("C:\\Users\\Admin\\Downloads\\Ankita P CV.pdf");
	driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("As an SDET with 2+ years of experience, I bring proficiency in both Manual and Automation Testing methodologies. My expertise includes a strong understanding of SDLC, STLC, Agile, and Web Services Testing. I am highly skilled in Selenium, TestNG, Java, BDD Cucumber, Selenium Webdriver, POM, and Jenkins, which I have used to design and develop efficient Test Automation Frameworks. Additionally, I have experience in Database Testing, MySQL, and Data Driven Frameworks. With excellent . analytical skills and attention to detail, I can quickly identify issues and develop solutions. My familiarity with JIRA and experience in Core Java enables me to collaborate effectively with development and QA teams. I am a quick learner, eager to take on new challenges, and committed to delivering high-quality results.");
	driver.findElement(By.xpath("//button[text()='APPLY NOW']")).click();
	String error = driver.findElement(By.xpath("//p[text()='something went wrong! please try again later']")).getText();
	System.out.println(error);
	
	
	
		
	}
	

}
